/*
2. Write a c program to set up a child-TO-parent pipe; the child
should 'exec' to perform a "pre" process and its output should be
connected to the pipe connected to the parent, which should 'exec' to
perform a "sort" process.
*/

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

int pl[2];
int pid;
char buff[20];

int main()
{
  pipe(pl);
  pid = fork();
  if (pid < 0)//error
  {
    printf("Fork failed");
    exit(-1);
  }
  else if (pid == 0)  //child executes
  {
    //reassign pl[1] to output
    close(1);
    dup(pl[1]);
    close(pl[1]);
    write(stdin, buff, sizeof(buff)); 
    execl("./pre", "pre", (char*)0);
    perror("execl() failed!");
  }
  else
  {  //reassign pl[0] to input
    wait(NULL);
    close(0);
    dup(pl[0]);
    close(pl[0]);
    close(pl[1]);
    write(stdin, buff, sizeof(buff)); 
    execl("./sort", "sort", (char*)0);
    perror("execl() failed!");
  }
  return 0;
}
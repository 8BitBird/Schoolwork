﻿To use pre.c, type in: name (space) gpa (return) then repeat for all entries.  The names can be up to 15 characters long and the list can hold 10 names of students.

To use sort.c, type in: name then (return) and type another name.  The names can be up to 15 characters long and the list can hold 10 names of students.

Fork runs normally when called and given commands.  (example: ./fork ls -t -l)

pipe.c accepts name (space) gpa (return), repeat and will print out the names in alphabetical order.

/*
1). The first program "pre.c"
should read in a list of student names and their GPAs. You can make up a list. To be simple, you
can make student name one word in lower cases. We assume there are at most 10 students in the list.
The input ends when an EOF is encountered. The output of the program should display the students
whose GPA is above 3.0.

For example, the following are the inputs to "pre.c" from keyboard:

Susan 3.9
Mary  3.6
Bob   2.8
John  4
Ctrl-D (to terminate the input.)

    then "pre.c" produces the output:
Susan
Mary
John

Note: an EOF is usually 'sent' to a process by hitting a CTRL_D.
If you type stty -a on your unix command line, you can get info that
tells you which keyboard keys mean what. FYI, in c, to put values to
standard_out  use printf().  To get values from standard_in use scanf()
or getchar().
*/



#include <stdio.h>
#include <string.h>

typedef struct {
    double gpa;
    char *name[15];
  }student;

int main()
{
    int count = 0;
    int i;
    student new_stud[10];
    while (!feof(stdin))
    {
     scanf("%s %lf", new_stud[count].name, &new_stud[count].gpa);
     count++;
    }
    for(i = 0; i < count; i++)
        {
            if (new_stud[i].gpa > 3.0)
            {
              printf("%s\n", new_stud[i].name);
            }
        }
    return 0;
}

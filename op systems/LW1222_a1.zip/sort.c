/*
2). The second program "sort.c" reads in a list of names from stdin and
outputs them in an alphabetical order. Assume there are no more than 10
names and the sequence is read until an EOF is encountered.

*/
#include <stdio.h>
#include <string.h>

typedef struct {
    char *name[15];
  }student;

int main()
{
    //char *name[];
    int count = 0;
    int i, j;
    student temp;
    student new_stud[10];
    while (!feof(stdin))
    {
     scanf("%s\n", new_stud[count].name);
     count++;
    }
    //sort
    for (i = 0; i < count; i++)
    {
        for (j = i + 1; j < count; j++)
        {
            if (strcmp(new_stud[i].name, new_stud[j].name) > 0)
                
            {
                temp = new_stud[i];
                new_stud[i] = new_stud[j];
                new_stud[j] = temp;
            }
        }
    }
    //print
    for (i = 0; i < count; i++)
      {
        printf("%s\n", new_stud[i].name);
      }
    return 0;
}

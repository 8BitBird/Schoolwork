/*
3. Write a program to take a UNIX command from the command line
and fork() a child to execute it. The command can be a simple
command like: $ls or $ps, Or it can be a command with options such as
$ls -t -l. Use argc and argv[] in the main function to pass parameters.
When the child process is executing the command, the parent process
simply waits for the termination of the child process. The process
id of the parent and the child should be printed out using getpid() and
getppid() functions
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

void main(int argc, char* argv[])
{
  int pid;
  pid = fork();
  if (pid < 0) //error
  {
    printf("Fork failed");
    exit(-1);
  }
  else if (pid == 0) //child process execute
  {
  	int pid_child = getpid();
  	printf("Child id = %i\n", pid_child);
    	execlp(argv[1], argc, NULL);
  }
  else
  {
    wait(NULL);
    int pid_par = getpid();
    printf("Parent id = %i\n", pid_par);
    printf("Child complete.\n" );
    exit(0);
  }
 
}

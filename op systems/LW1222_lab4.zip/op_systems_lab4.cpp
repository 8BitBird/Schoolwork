#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <iostream>
#include <algorithm>
#include <vector> 


int str[20], i, k, m, p, q, x, t, d, v, w, oaPF = 0, lruPF = 0, numFrames; 
int *replaceFrame, *ord, *reverse_max_ord, *LRUreplaceF;
bool pf;

int * getOrder(int  new_str[])
{	
	int maxIndex = 0;
	int  max_ord[5] = {0,0,0,0,0};
	for (int qrs = 0; qrs < 5; qrs++)	//for 0-4 order of max
	{
		for (int tuv = 1; tuv < 6; tuv++) //for 1-5 order of max
		{
			if(new_str[tuv] > new_str[maxIndex])	//compare values in counter
			    maxIndex = tuv;	//determine index w highest value
		}
		max_ord[qrs] = maxIndex;	
		new_str[maxIndex] = 0;
	}
	return max_ord;
}

/////////////////////////////////////////
int rev_count(int nPos, int target, int rString[])
{
	int countAppearance = 0;
    for (nPos; nPos >= 0; nPos--)
    {	countAppearance++;
		if (rString[nPos] == target)
			return countAppearance;
	}
	return countAppearance;
}
//////////////////////////////////////
int fwdCount(int fwdPos, int fwdTarget, int fwdString[])
{
	int countAppear = 0;
    for (fwdPos; fwdPos < 20; fwdPos++)
    {	countAppear++;
		if (fwdString[fwdPos] == fwdTarget)
			return countAppear;
	}
	return countAppear;
}
/////////////////////////////////////////
int *reverseCallCount(int mypos, int rev_str[])	//find past farthest away value, return it.
{
	int fill = 1;
	int reverseCounter[6] = {0,0,0,0,0,0}; 
	for (fill; fill < 6; fill++)
 		reverseCounter[fill] = rev_count(mypos-1, fill, rev_str);
	reverse_max_ord = getOrder(reverseCounter);
	return reverse_max_ord;
}
/////////////////////////////////////////
int *callCount(int pos, int str[20])	//find farthest away value, return it.
{	
	int goal = 1;
	int counter[6] = {0,0,0,0,0,0};
	for (goal; goal < 6; goal++)
	{
		counter[goal] = fwdCount(pos+1, goal, str);
	}
	for (int clean = goal; clean < 6; clean++)
	{
		if (counter[clean] == (19-pos));
			counter[clean] = 0;
	}
	ord = getOrder(counter);
	if (ord[0] == ord[1])
		ord = reverseCallCount(pos-1, str);		//FIFO
	return ord;
}
/////////////MAIN/////////////////
int main()
{
    std::cout << "Input number of frames: " << std::endl;
    std::cin >> numFrames;
    std::cout << std::endl;
    int displayArr[numFrames+1][20] = { 0 };

	srand(time(NULL));  
    std::cout << "Optimal Algorithm:\n" << std::endl;
	for (int i = 0; i < 20; i++)
	{
		str[i] = rand() % 5 + 1;
		std::cout << str[i] << ",   ";
	}
		/////////OPTIMAL///////////////////////
	for (int i = 0; i < 20; i++)	//go through all page calls (columns)
	{	
		pf = true;
		for (k = 0; k < numFrames; k++)	//go through all frames for that page (row)
		{
			if (i > 0)
				displayArr[k][i] = displayArr[k][i-1];	// copy last iteration to current	
		}
		for (k = 0; k < numFrames; k++)	//go through all frames for that page (row)
		{
			if (displayArr[k][i] == str[i])	// if page already found in frames, go to next page
			{
				pf = false;
				goto exit_loop;
			}	
		}
		
		///where to replace??	
		oaPF++;
		displayArr[numFrames][i] = -1;
        for (x = 0; x < numFrames; x++) //check if any still empty
		{
			if (displayArr[x][i] == 0)	//replace blank spot with new page
			{
				displayArr[x][i] = str[i];
				goto here;
			}
		}
		
	//determine farthest away page, return farthest pages in order
		replaceFrame = callCount(i, str); 
		for (w = 0; w < 5; w++)	 
		{	
			for (v = 0; v < numFrames; v++)	 
			{	
				if ( displayArr[v][i] == replaceFrame[w])	// compares all frames with top page, then second page...
				{		
					displayArr[v][i] = str[i];
					goto replaced;
				}
			}	
		}
		replaced:;
        here:;
		exit_loop:;
	}

	   //display
	   std::cout << "\n";
        for (int p = 0; p < 20; p++)
        	std::cout << "--   ";
        	
        for (int q = 0; q < numFrames; q++)
        {	std::cout << "\n";
            for (int p = 0; p < 20; p++)
            std::cout << displayArr[q][p] << "    ";
        }
        std::cout << "\n";
        for (m = 0; m < 20; m++)
        {
            if (displayArr[numFrames][m] == -1)
            	std::cout << "*    ";
            else
                std::cout << "     ";
        }
        std::cout << "\n\nThere were " << oaPF << " page faults.";
    
    /////////LRU///////////////////////
    int displayArr2[numFrames+1][20] = { 0 };
    std::cout << "\n\n\n\nLRU Algorithm:\n" << std::endl;
    for (int i = 0; i < 20; i++)
	{
		std::cout << str[i] << ",   ";
	}
    
	bool LRUpf = true;
	for (int i = 0; i < 20; i++)	//go through all page calls (columns)
	{	
		LRUpf = true;
		for (k = 0; k < numFrames; k++)	//go through all frames for that page (row)
		{
			if (i > 0)
				displayArr2[k][i] = displayArr2[k][i-1];	// copy last iteration to current	
		}
		for (k = 0; k < numFrames; k++)	//go through all frames for that page (row)
		{
			if (displayArr2[k][i] == str[i])	// if page already found in frames, go to next page
			{
				LRUpf = false;
				goto exit_loop2;
			}	
		}
		
		///where to replace??	
		lruPF++;
		displayArr2[numFrames][i] = -1;
        for (x = 0; x < numFrames; x++) //check if any still empty
		{
			if (displayArr2[x][i] == 0)	//replace blank spot with new page
			{
				displayArr2[x][i] = str[i];
				goto here2;
			}
		}
		
	//determine farthest away page, return farthest pages in order
		LRUreplaceF = reverseCallCount(i, str); 
		for (w = 0; w < 5; w++)	 
		{	
			for (v = 0; v < numFrames; v++)	 
			{	
				if ( displayArr2[v][i] == LRUreplaceF[w])	// compares all frames with top page, then second page...
				{		
					displayArr2[v][i] = str[i];
					goto replaced2;
				}
			}	
		}
		replaced2:;
        here2:;
		exit_loop2:;
	}

	   //display
	   std::cout << "\n";
        for (int p = 0; p < 20; p++)
        	std::cout << "--   ";
        	
        for (int q = 0; q < numFrames; q++)
        {	std::cout << "\n";
            for (int p = 0; p < 20; p++)
            std::cout << displayArr2[q][p] << "    ";
        }
        std::cout << "\n";
        for (m = 0; m < 20; m++)
        {
            if (displayArr2[numFrames][m] == -1)
            	std::cout << "*    ";
            else
                std::cout << "     ";
        }
        std::cout << "\n\nThere were " << lruPF << " page faults.\n\n";
       
       system("pause");	//wait for key input to exit
	return 0;
}
